package com.yorbax.a170311usaammc;

interface RVClickDelListener {
    void onItemDelete(int position,Object item);
}
